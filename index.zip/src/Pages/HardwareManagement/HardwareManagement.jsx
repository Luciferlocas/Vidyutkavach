import React from 'react'

const HardwareManagement = () => {
  return (
    <div className="grid grid-cols-3 h-screen">
      
    </div>
  )
}

export default HardwareManagement
